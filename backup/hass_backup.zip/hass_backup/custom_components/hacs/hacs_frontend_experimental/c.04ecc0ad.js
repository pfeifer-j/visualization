const s=(s,a)=>t(s.attributes,a),t=(s,t)=>0!=(s.supported_features&t);export{t as a,s};
