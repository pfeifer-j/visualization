const s=s=>s.substr(s.indexOf(".")+1);export{s as c};
