import{c}from"./c.d2f13ac1.js";const t=t=>c(t.entity_id);export{t as c};
